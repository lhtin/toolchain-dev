from django.apps import AppConfig


class platoConfig(AppConfig):
    name = 'platoSite'
