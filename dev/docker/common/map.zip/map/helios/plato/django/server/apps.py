from django.apps import AppConfig


class platoServer(AppConfig):
    name = 'server'
