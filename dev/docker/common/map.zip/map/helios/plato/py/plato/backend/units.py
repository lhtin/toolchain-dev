# Unit constants
class Units:
    CYCLES = 'cycles'
    BRANCH_TRAINING_INDEX = 'training-index'
    INSTRUCTIONS = 'instructions'
