CookieNames = {
    USERNAME: 'username',
}
