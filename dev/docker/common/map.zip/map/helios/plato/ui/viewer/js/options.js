// Global options (e.g. debugging)
Options = {
    DEBUG_LATENCY: false, // Show debug latency information in widgets
    TRACE_LATENCY: false, // Show latency messages in logs
    SHOW_TEST_WIDGETS: true, // Show test widgets
}