# Mavis

Mavis is a framework that allows decoding of the RISC-V ISA into
custom instruction class types as well as custom extensions to those
class types.

## Building

Mavis is a header-only library.  To build a tester:

```
cd test
cmake .
make
./Mavis
```
