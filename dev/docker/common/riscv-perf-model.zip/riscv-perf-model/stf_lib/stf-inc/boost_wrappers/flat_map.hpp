#ifndef __BOOST_FLAT_MAP_HPP__
#define __BOOST_FLAT_MAP_HPP__

#include <boost/container/flat_map.hpp>

#endif
