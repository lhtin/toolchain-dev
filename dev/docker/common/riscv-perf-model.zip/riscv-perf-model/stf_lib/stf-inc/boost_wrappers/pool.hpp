#ifndef __BOOST_POOL_HPP__
#define __BOOST_POOL_HPP__

#pragma push_macro("T0")
#undef T0
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wconversion"
#include <boost/pool/pool_alloc.hpp>
#pragma GCC diagnostic pop
#pragma pop_macro("T0")

#endif
