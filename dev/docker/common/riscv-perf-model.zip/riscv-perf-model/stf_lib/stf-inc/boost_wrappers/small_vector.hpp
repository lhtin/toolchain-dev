#ifndef __BOOST_SMALL_VECTOR_HPP__
#define __BOOST_SMALL_VECTOR_HPP__

#pragma push_macro("S1")
#undef S1
#include <boost/container/small_vector.hpp>
#pragma pop_macro("S1")

#endif
